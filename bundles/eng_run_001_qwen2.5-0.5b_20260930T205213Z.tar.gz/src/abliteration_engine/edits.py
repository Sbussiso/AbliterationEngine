"""eng edits — persistent-edit ladder (stage B), FTT-18/FTT-20.

Faithful port of ladder_003.py into spec-driven form. The verified mechanics
documented there carry over unchanged:

- lm_head edits go to a CLONED UNTIED parameter; config.tie_word_embeddings
  flipped to false before save (Qwen2.5 0.5B/1.5B ship tied).
- Row-space edits: the orthogonality invariant is (M W)^T r ~= 0, NOT (M W) r.
- Every variant is saved, RELOADED FROM DISK, verified on disk, then probed.

Selection: gate = benign_preserved >= baseline - gates.benign_floor_delta AND
degenerate == 0; pick lowest refusal among gate-passers (tie-break: ladder
order). publish_eligible = selected passed gate AND refusal <
gates.publish_refusal. MMLU guardrail is enforced later by eng/mmlu.py
before any publish.
"""
import gc
import json
import os
import shutil
import time

import numpy as np
import torch

from abliteration_engine import core


def orthogonalize_lm_head(model, direction):
    """W <- W - (W r) r^T on a CLONED, UNTIED parameter; flips
    config.tie_word_embeddings. Returns (max|W r| after edit, |r_hat|)."""
    lm = model.get_output_embeddings()
    assert lm is not None, "no output embeddings"
    r = direction.detach().float().cpu()
    r = r / r.norm()
    W = lm.weight.data
    W32 = W.float().cpu()
    proj = (W32 @ r).unsqueeze(1) * r.unsqueeze(0)
    W_new = (W32 - proj).to(W.dtype)
    max_comp = float((W_new.float() @ r).abs().max().item())
    lm.weight = torch.nn.Parameter(W_new.to(W.device), requires_grad=False)
    model.config.tie_word_embeddings = False
    return max_comp, float(r.norm().item())


def orthogonalize_final_norm(model, direction):
    """w <- w - (w.d) d on the final RMSNorm weight (readout-space
    direction). Returns (w.d before, |w_new . d| after edit-in-fp32)."""
    n = core.final_norm_module(model)
    d = direction.detach().float().cpu()
    d = d / d.norm()
    w = n.weight.data
    w32 = w.float().cpu()
    comp = float(w32 @ d)
    w_new = w32 - comp * d
    resid = float(abs(w_new @ d))
    n.weight = torch.nn.Parameter(w_new.to(w.dtype).to(w.device),
                                  requires_grad=False)
    return comp, resid


def orthogonalize_layer_output(model, layer_idx, direction):
    """Row-space edit at one decoder layer: W <- M W, M = I - r r^T for
    o_proj and down_proj (residual-stream output matrices). Invariant:
    (M W)^T r ~= 0 (row-space, not column-space — run-002 gotcha)."""
    layer = model.model.layers[layer_idx]
    r = direction.detach().float().cpu()
    r = r / r.norm()
    M = torch.eye(r.shape[0]) - torch.outer(r, r)
    resids = {}
    for label, lin in (("self_attn.o_proj", layer.self_attn.o_proj),
                       ("mlp.down_proj", layer.mlp.down_proj)):
        W = lin.weight.data
        W_new = (M @ W.float().cpu()).to(W.dtype).to(W.device)
        resid = float((W_new.float().cpu().T @ r).abs().max().item())
        assert resid < 1e-3, (layer_idx, label, resid)
        lin.weight = torch.nn.Parameter(W_new, requires_grad=False)
        resids[label] = resid
    return resids


def verify_untied(model):
    lm = model.get_output_embeddings()
    emb = model.get_input_embeddings()
    tied = lm.weight.data_ptr() == emb.weight.data_ptr()
    diff = float((lm.weight.float() - emb.weight.float()).norm().item())
    return {"tied": bool(tied), "weight_diff_l2": diff,
            "config_flag": model.config.tie_word_embeddings}


def save_variant(model, tok, out_dir, expect_tied):
    os.makedirs(out_dir, exist_ok=True)
    model.save_pretrained(out_dir, safe_serialization=True)
    tok.save_pretrained(out_dir)
    cfg = json.load(open(os.path.join(out_dir, "config.json")))
    assert cfg["tie_word_embeddings"] is expect_tied, \
        (cfg["tie_word_embeddings"], expect_tied)
    return out_dir


def verify_lm_head_disk(model_r, dir_vec, bound=5e-3):
    """Bound tolerates fp16 reload quantization noise (~3e-4 scale for a
    1536-dim dot with ~0.03-magnitude entries); a real incomplete edit
    leaves |W r| orders of magnitude higher."""
    lm = model_r.get_output_embeddings()
    d = dir_vec.detach().float().cpu()
    d = d / d.norm()
    resid = float((lm.weight.data.float().cpu() @ d).abs().max().item())
    assert resid < bound, resid
    return resid


def verify_final_norm_disk(model_r, dir_vec, bound=5e-2):
    """fp16 reload noise on a hidden-size (1536) dot of ~1.0-magnitude
    RMSNorm weights is ~1e-2; pre-edit alignment |w.d| is O(0.1+) so 5e-2
    cleanly separates 'edit survived' from 'edit lost'."""
    n = core.final_norm_module(model_r)
    d = dir_vec.detach().float().cpu()
    d = d / d.norm()
    resid = float(abs((n.weight.data.float().cpu() * d).sum().item()))
    assert resid < bound, resid
    return resid


def verify_layers_disk(model_r, layers, dirs_np, bound=1e-2):
    """fp16 reload noise ~3e-4 scale; 1e-2 leaves 30x headroom."""
    out = {}
    for l in layers:
        layer = model_r.model.layers[l]
        r = torch.from_numpy(np.asarray(dirs_np[l])).float()
        r = r / r.norm()
        Wo = layer.self_attn.o_proj.weight.data.float().cpu()
        Wd = layer.mlp.down_proj.weight.data.float().cpu()
        ro = float((Wo.T @ r).abs().max().item())
        rd = float((Wd.T @ r).abs().max().item())
        assert ro < bound and rd < bound, (l, ro, rd)
        out[str(l)] = {"o_proj": ro, "down_proj": rd}
    return out


def run_variant(name, edit_fn, out_dir, expect_tied, verify_fn, spec,
                tok_source_model):
    """Fresh base load -> edit -> save -> RELOAD from disk -> verify ->
    probe. Returns summary dict; dumps probes_<name>.json."""
    print(f"      --- {name} ---", flush=True)
    t0 = time.time()
    tok_v, model_v = core.load_patient(spec)
    edit_info = edit_fn(model_v)
    print(f"      edit applied: {json.dumps(edit_info, default=str)}",
          flush=True)
    save_variant(model_v, tok_v, out_dir, expect_tied=expect_tied)
    del model_v
    gc.collect()
    torch.cuda.empty_cache()

    # persistence check: reload FROM DISK, verify, probe
    tok_r, model_r = core.load_patient({"patient": {
        "model_id": out_dir, "revision": None}})
    disk = verify_fn(model_r)
    flag = model_r.config.tie_word_embeddings
    assert flag is expect_tied, (flag, expect_tied)
    if not expect_tied:
        chk = verify_untied(model_r)
        assert not chk["tied"] and chk["weight_diff_l2"] > 0, chk
    n_probes = spec["probe_sets"]["n_probes"]
    max_new = spec["decoding"]["max_new_tokens"]
    from abliteration_engine.data import resolve_probe_set
    harmful = resolve_probe_set(spec["probe_sets"]["harmful"])[:n_probes]
    harmless = resolve_probe_set(spec["probe_sets"]["harmless"])[:n_probes]
    r_h = core.run_probes(tok_r, model_r, harmful, tag=f"{name}-harm",
                          max_new=max_new)
    r_b = core.run_probes(tok_r, model_r, harmless, tag=f"{name}-harmless",
                          max_new=max_new)
    s = core.summarize(r_h, r_b)
    s["edit_info"] = edit_info
    s["on_disk_verify"] = disk
    s["tie_flag_on_disk"] = flag
    s["wall_s"] = round(time.time() - t0, 1)
    json.dump({"harmful": r_h, "harmless": r_b},
              open(os.path.join(core._out_dir(spec),
                                f"probes_{name}.json"), "w"), indent=2)
    print(f"      {name} reloaded: refusal={s['refusal_rate']} "
          f"benign={s['benign_preserved']} "
          f"degenerate={s['degenerate_total']}", flush=True)
    del model_r
    gc.collect()
    torch.cuda.empty_cache()
    return s


def select_variant(candidates, base_preserved, publish_refusal,
                   floor_delta=0.10):
    """Deterministic selection over gate-passers with tie-break ladder
    order; publish_eligible only when the gate passed AND refusal < 
    publish_refusal. Gate threshold comes from spec gates.benign_floor_delta."""
    for c in candidates:
        c["passes_gate"] = (c["benign_preserved"] >= base_preserved - floor_delta
                            and c["degenerate_total"] == 0)
    gated = [c for c in candidates if c["passes_gate"]]
    if gated:
        selected = min(gated, key=lambda c: (c["refusal_rate"],
                                             c["ladder_index"]))
        eligible = selected["refusal_rate"] < publish_refusal
    else:
        selected = min(candidates, key=lambda c: (c["refusal_rate"],
                                                  c["degenerate_total"],
                                                  c["ladder_index"]))
        eligible = False
    return selected, eligible


def run_ladder(spec, ctx):
    """Stage B: the ladder from spec.ladder.variants over v2 stage-A
    artifacts. Returns the LADDER_DONE payload dict."""
    out_dir = ctx["out_dir"]
    lad = spec["ladder"]
    variants = lad["variants"]

    lc = json.load(open(os.path.join(out_dir, "layer_coherence.json")))
    dirs_np = np.load(os.path.join(out_dir, "layer_directions.npz"))
    dirs_all = dirs_np["directions"]
    dir_A = torch.from_numpy(
        np.load(os.path.join(out_dir, "refusal_direction_A.npy"))).float()
    dir_B = torch.from_numpy(
        np.load(os.path.join(out_dir, "refusal_direction_B.npy"))).float()
    base = json.load(open(os.path.join(out_dir, "probes_baseline.json")))
    base_sum = core.summarize(base["harmful"], base["harmless"])
    base_pres = base_sum["benign_preserved"]
    table = sorted(lc["table"], key=lambda r: -r["coherence"])
    k_layers_primary = [r["decoder_layer"] for r in table[:lad["k_primary"]]]
    k_layers_combo = [r["decoder_layer"] for r in table[:lad["k_combo"]]]
    print(f"[1/6] ladder plan: L*={lc['best']['decoder_layer']} "
          f"coh={lc['best']['coherence']} K_primary={k_layers_primary} "
          f"K_combo={k_layers_combo} "
          f"baseline_refusal={base_sum['refusal_rate']} "
          f"benign={base_pres}", flush=True)

    VARBASE = os.environ.get("ENG_VARBASE", "/content")
    VAR_DIRS = {v: f"{VARBASE}/{v}" for v in variants}

    def edit_wd_B(m):
        mc, rn = orthogonalize_lm_head(m, dir_B)
        return {"lm_head_max|W r_B|": mc, "r_norm": rn}

    def edit_wd_BN(m):
        mc, rn = orthogonalize_lm_head(m, dir_B)
        comp, resid = orthogonalize_final_norm(m, dir_B)
        return {"lm_head_max|W r_B|": mc, "norm_wdB_before": comp,
                "norm_resid_fp32": resid}

    def make_edit_wd_ML(k_layers):
        def _edit(m):
            info = {}
            for l in k_layers:
                info[f"L{l}"] = orthogonalize_layer_output(
                    m, l, torch.from_numpy(dirs_all[l]).float())
            return {"layers": k_layers, "resids": info}
        return _edit

    def edit_wd_ML_BN(m):
        info = {"layers": k_layers_combo, "resids": {}}
        for l in k_layers_combo:
            info["resids"][f"L{l}"] = orthogonalize_layer_output(
                m, l, torch.from_numpy(dirs_all[l]).float())
        mc, rn = orthogonalize_lm_head(m, dir_B)
        comp, resid = orthogonalize_final_norm(m, dir_B)
        info["lm_head_max|W r_B|"] = mc
        info["norm_wdB_before"] = comp
        info["norm_resid_fp32"] = resid
        return info

    bounds = spec["publish"].get("verify_disk_bounds", {})
    b_lm = bounds.get("lm_head", 5e-3)
    b_norm = bounds.get("final_norm", 5e-2)
    b_row = bounds.get("layer_row", 1e-2)

    def vfy_wd_B(mr):
        return {"lm_head": verify_lm_head_disk(mr, dir_B, b_lm)}

    def vfy_wd_BN(mr):
        return {"lm_head": verify_lm_head_disk(mr, dir_B, b_lm),
                "final_norm": verify_final_norm_disk(mr, dir_B, b_norm)}

    def vfy_wd_ML(mr):
        return {"layers": verify_layers_disk(mr, k_layers_primary, dirs_all,
                                             b_row)}

    def vfy_wd_ML_BN(mr):
        return {"lm_head": verify_lm_head_disk(mr, dir_B, b_lm),
                "final_norm": verify_final_norm_disk(mr, dir_B, b_norm),
                "layers": verify_layers_disk(mr, k_layers_combo, dirs_all,
                                             b_row)}

    expect_tied = {"wd_B": False, "wd_BN": False, "wd_ML": True,
                   "wd_ML_BN": False}
    edit_fns = {"wd_B": edit_wd_B, "wd_BN": edit_wd_BN}
    edit_fns["wd_ML"] = make_edit_wd_ML(k_layers_primary)
    edit_fns["wd_ML_BN"] = edit_wd_ML_BN
    verify_fns = {"wd_B": vfy_wd_B, "wd_BN": vfy_wd_BN, "wd_ML": vfy_wd_ML,
                  "wd_ML_BN": vfy_wd_ML_BN}

    summ = {}
    step = 2
    for name in variants:
        if name == "wd_ML_BN":
            continue  # conditional, after the others
        print(f"[{step}/6] {name}", flush=True)
        summ[name] = run_variant(name, edit_fns[name], VAR_DIRS[name],
                                 expect_tied[name], verify_fns[name], spec,
                                 ctx["model"])
        step += 1

    # conditional max-intervention combo per v2 semantics
    if "wd_ML_BN" in variants:
        best3 = min(summ[v]["refusal_rate"]
                    for v in variants if v != "wd_ML_BN")
        if best3 >= spec["gates"]["publish_refusal"]:
            print(f"[{step}/6] wd_ML_BN: best of V1..V3 = {best3} >= "
                  f"{spec['gates']['publish_refusal']} -> running combo",
                  flush=True)
            summ["wd_ML_BN"] = run_variant(
                "wd_ML_BN", edit_fns["wd_ML_BN"], VAR_DIRS["wd_ML_BN"],
                expect_tied["wd_ML_BN"], verify_fns["wd_ML_BN"], spec,
                ctx["model"])
        else:
            print(f"[{step}/6] wd_ML_BN skipped: best of V1..V3 = {best3} "
                  f"< {spec['gates']['publish_refusal']}", flush=True)
        step += 1

    print(f"[{step + 1}/6] selection + artifacts", flush=True)
    cands = []
    for idx, name in enumerate(variants):
        if name not in summ:
            continue
        s = summ[name]
        cands.append({"variant": name, "ladder_index": idx,
                      "refusal_rate": s["refusal_rate"],
                      "benign_preserved": s["benign_preserved"],
                      "degenerate_total": s["degenerate_total"]})
    selected, eligible = select_variant(
        cands, base_pres, spec["gates"]["publish_refusal"],
        floor_delta=spec["gates"]["benign_floor_delta"])
    print(f"      selection: {selected['variant']} "
          f"(gate={'passed' if selected['passes_gate'] else 'failed'}, "
          f"publish_eligible={eligible})", flush=True)

    sel_dir = VAR_DIRS[selected["variant"]]
    # representative direction for hub aux file: readout-space dir_B for
    # lm_head-bearing variants, residual-space dir_A otherwise
    rep = (dir_B if selected["variant"] in ("wd_B", "wd_BN", "wd_ML_BN")
           else dir_A)
    np.save(os.path.join(out_dir, "refusal_direction.npy"), rep.numpy())
    json.dump(cands, open(os.path.join(out_dir, "selection_candidates.json"),
                          "w"), indent=2)
    json.dump({"selected": selected["variant"],
               "gate": "passed" if selected["passes_gate"] else "failed",
               "selected_variant_dir": sel_dir,
               "publish_eligible_probe_gate": eligible,
               "publish_refusal_threshold":
                   spec["gates"]["publish_refusal"],
               "k_layers_primary": k_layers_primary,
               "k_layers_combo": k_layers_combo,
               "metrics": {
                   "refusal_rate_before": base_sum["refusal_rate"],
                   "refusal_rate_after": selected["refusal_rate"],
                   "benign_preserved_before": base_pres,
                   "benign_preserved_after":
                       selected["benign_preserved"]}},
              open(os.path.join(out_dir, "selection.json"), "w"), indent=2)

    for name, d in VAR_DIRS.items():
        if name != selected["variant"] and os.path.isdir(d):
            shutil.rmtree(d, ignore_errors=True)
            print(f"      removed non-selected {name} dir", flush=True)

    return {"selected": selected["variant"],
            "gate": "passed" if selected["passes_gate"] else "failed",
            "publish_eligible_probe_gate": eligible,
            "metrics": {
                "refusal_rate_before": base_sum["refusal_rate"],
                "refusal_rate_after": selected["refusal_rate"],
                "benign_preserved_before": base_pres,
                "benign_preserved_after": selected["benign_preserved"]},
            "variants": {k: {"refusal_rate": v["refusal_rate"],
                             "benign_preserved": v["benign_preserved"],
                             "degenerate_total": v["degenerate_total"]}
                         for k, v in summ.items()}}